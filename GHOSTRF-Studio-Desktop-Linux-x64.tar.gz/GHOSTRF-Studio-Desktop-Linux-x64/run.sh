#!/usr/bin/env bash
# ==============================================================================
# GHOSTRF STUDIO DESKTOP LAUNCHER
# ESP32-C3 + CC1101 SUB-1GHz & 2.4GHz WORKSPACE TERMINAL
# ==============================================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export LD_LIBRARY_PATH="$SCRIPT_DIR/lib:${LD_LIBRARY_PATH:-}"
export QT_PLUGIN_PATH="$SCRIPT_DIR/plugins"
export QT_QPA_PLATFORM_PLUGIN_PATH="$SCRIPT_DIR/plugins/platforms"
export QT_QPA_PLATFORM="${QT_QPA_PLATFORM:-xcb}"


# Check serial permissions on Linux
if ! groups 2>/dev/null | grep -qE 'dialout|uucp'; then
    echo "[!] Рекомендация: Для доступа к USB-Serial порту ESP32 без root-прав выполните:"
    echo "    sudo usermod -a -G dialout $USER   (Ubuntu / Debian / Mint / Pop!_OS)"
    echo "    sudo usermod -a -G uucp $USER      (Arch Linux / Manjaro)"
    echo ""
fi

chmod +x "$SCRIPT_DIR/GHOSTRF-Studio"
exec "$SCRIPT_DIR/GHOSTRF-Studio" "$@"
